<?php
require_once(dirname(__FILE__) . "/vb_dir.php");
chdir($vb_dir);
require_once($vb_dir . '/content.php');
?>
