<?php

//If you installed the blog directly as a subdirectory of 
//vbulletin (www.example.com/blog) then you don't need to change this
//file.  Otherwise comment out the first line, uncomment the second line,
//and change the value to be the actual path to the vbulletin installation on
//server.  

$vb_dir = realpath(dirname(__FILE__) . '/..');
//$vb_dir = "/path/to/vbulletin/";
?>
